﻿Imports System.Collections.Generic
Imports System.Linq
Public Interface IDBConnect


    'connect
    Function GetAllPlayers() As List(Of String)

    'insert
    Function InsertGame() As String

    Function InsertPlayer() As String

    'pull up
    Function GetGames(playerName2 As String) As String()

    Function GetPlayers() As String


    Function getResults()




    'close



End Interface
