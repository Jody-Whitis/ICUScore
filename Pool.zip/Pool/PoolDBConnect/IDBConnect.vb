﻿Imports System.Collections.Generic
Imports System.Linq
Public Interface IDBConnect


    'connect


    'insert
    Sub InsertGame()

    Sub InsertPlayer()

    'pull up
    Function GetGames()

    Function GetPlayers() As String


    Function getResults()




    'close



End Interface
