﻿Public Class HighScores
    Dim player As New PlayerStats
    Dim screen As New AppState
    Dim games As New Games
    Public Enum AppState
        NoPlayerEx = -1
        Start = 0
        Register = 1
        SelectPlayer = 2
        Winner = 3
        Switch = 4
    End Enum

    Private Sub HighScores_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        screen = AppState.Start
        Dim allPlayers As List(Of String) = player.IDBConnect_GetAllPlayers()
        GetAll(allPlayers, cbPlayers)
        Dim allGames As List(Of String) = games.GetAllPlayers()
        GetAll(allGames, cbGames)

        lblError.Visible = False
        If screen = -1 Then
            lblError.Visible = True
        Else
            screen = AppState.SelectPlayer
        End If

    End Sub

    Private Sub GetAll(allList As List(Of String), ByRef cBox As ComboBox)
        For Each name As String In allList
            If screen = 0 AndAlso name.Contains("Error") Then
                screen = -1
                lblError.Text = "Error getting all players"
                Exit For
            Else
                cBox.Items.Add(name)
                screen = AppState.SelectPlayer
            End If
        Next
    End Sub
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        lblError.Visible = False
        Dim score As Integer = -1
        If screen > 0 Then
            'got a player
            If Not String.IsNullOrEmpty(cbPlayers.SelectedItem.ToString) Then
                'got a new score
                If Not String.IsNullOrEmpty(txtScore.Text) Then
                    If Integer.TryParse(txtScore.Text.Trim, score) Then
                        screen = AppState.Winner
                        With player
                            .PlayerName1 = cbPlayers.SelectedItem.ToString
                            .Wins1 = score
                        End With
                    Else
                        lblError.Text = "Error: nan"
                        SetError(lblError)
                    End If

                Else
                        screen = AppState.SelectPlayer
                    Dim currentScore As String() = Nothing
                    Try
                        txtScore.Text = currentScore(0)
                    Catch ex As Exception
                        lblError.Text = "error"
                    End Try
                    SetError(lblError)
                End If
            End If
        Else
            lblError.Text = "Error"
            SetError(lblError)
            screen = 1
        End If

    End Sub
    Protected Sub SetError(ByRef errorText As Label)
        If errorText.Text.Contains("Error") Then
            errorText.ForeColor = Color.Red
            errorText.Visible = True
        Else
            errorText.Visible = False
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub cbPlayers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbPlayers.SelectedIndexChanged
        If screen = AppState.SelectPlayer Then
            player.PlayerName1 = cbPlayers.SelectedItem
            SetError(lblError)
        End If
    End Sub

    Private Sub cbGames_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbGames.SelectedIndexChanged
        If screen = AppState.SelectPlayer Then
            games.GameMode = cbGames.SelectedItem
            SetError(lblError)
        End If

    End Sub

End Class