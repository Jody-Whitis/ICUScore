﻿Imports System.IO

Public Class Form1
    'Dim connectionString As String = ("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" & Path.GetDirectoryName(Application.StartupPath) & "\LocalResults.mdf;Integrated Security=True").Replace("\bin", "")
    'Dim connectionString As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\jwhitis\source\repos\Pool\Pool\LocalResults.mdf;Integrated Security=True"
    Dim player1 As New PlayerStats
    Dim player2 As New PlayerStats
    Dim screen As New AppState
    Dim isRiv As Boolean = False
    Public Enum AppState
        NoPlayerEx = -1
        Start = 0
        Register = 1
        SelectPlayer = 2
        Winner = 3
        Switch = 4
    End Enum

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LocalResultsDataSet1.Players' table. You can move, or remove it, as needed.
        'Me.PlayersTableAdapter1.Fill(Me.LocalResultsDataSet1.Players)
        'TODO: This line of code loads data into the 'PlayerNames.Players' table. You can move, or remove it, as needed.
        'Me.PlayersTableAdapter.Fill(Me.PlayerNames.Players)
#Region "Load all current Players into cbox"
#Region "Beta select all SQL"
        'Dim adapter As New SqlDataAdapter
        'Dim ds As New DataSet
        'Dim dbCommand As New SqlCommand
        'Dim sqlConnection As New SqlConnection
        'With sqlConnection
        '    .ConnectionString = connectionString
        '    .Open()
        'End With

        'adapter = New SqlDataAdapter("Select Playername from Players", sqlConnection)
        'adapter.Fill(ds)

        'Try
        '    For i = 0 To ds.Tables(0).Rows.Count - 1
        '        cbPlayer1.Items.Add(ds.Tables(0).Rows(i).Item(0))
        '        cbPlayer2.Items.Add(ds.Tables(0).Rows(i).Item(0))
        '    Next
        'Catch ex As Exception
        '    sqlConnection.Close()
        '    lblError.Text = "can't fetch data source Player Names"
        '    lblError.Visible = True
        'Finally
        '    sqlConnection.Close()
        'End Try
#End Region

        Dim allPlayers As Hashtable = player1.IDBConnect_GetAllPlayers()
        For Each player As DictionaryEntry In allPlayers
            If screen = 0 AndAlso player.Value.Equals("Error") Then
                screen = -1
                lblError.Text = "Error getting all players"
                Exit For
            Else
                cbPlayer1.Items.Add(player.Value)
                cbPlayer2.Items.Add(player.Value)
                screen = AppState.SelectPlayer
            End If
        Next

#End Region

        Dim results As String = String.Empty
        lblError.Visible = False
        If screen = -1 Then
            lblError.Visible = True
            txtResults.Visible = True
        Else
            screen = AppState.Start
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim player1 As String = String.Empty
        Dim wins As Integer = 0
        Dim isRivarly As Boolean = False
        tbPlayer1.Visible = False
        tbPlayer2.Visible = False
        lblError.Visible = False
        txtWins.Visible = True
        txtWins2.Visible = True

        If screen > 0 Then
            If Not String.IsNullOrEmpty(cbPlayer1.SelectedItem.ToString) And Not String.IsNullOrEmpty(cbPlayer2.SelectedItem.ToString) Then
#Region "if wins are not empty then add new game, else display wins"
                If Not String.IsNullOrEmpty(txtWins.Text) AndAlso Not String.IsNullOrEmpty(txtWins2.Text) Then
                    screen = AppState.Winner
#Region "beta get games SQL"
                    'With sqlConnection
                    '    .ConnectionString = connectionString
                    '    .Open()
                    'End With

                    'adapter = New SqlDataAdapter("Select wins from Players where playerName In ('" & cbPlayer1.SelectedItem.ToString & "','" & cbPlayer2.SelectedItem.ToString & "')", sqlConnection)
                    'adapter.Fill(ds)

                    ''save new wins if null txtbox wins, else then insert new game results.
                    'Try
                    '    txtWins.Text = ds.Tables(0).Rows(0).Item(0).ToString
                    '    txtWins2.Text = ds.Tables(0).Rows(1).Item(0).ToString
                    'Catch ex As Exception
                    '    sqlConnection.Close()
                    '    lblError.Text = "Name not found"
                    '    lblError.Visible = True
                    'Finally
                    '    sqlConnection.Close()

                    'End Try
#End Region
                    With Me.player1
                        .PlayerName1 = cbPlayer1.SelectedItem.ToString
                        .Wins1 = txtWins.Text
                    End With
                    With player2
                        .PlayerName1 = cbPlayer2.SelectedItem.ToString
                        .Wins1 = txtWins2.Text
                    End With
                    btnPlayer1win.Text = Me.player1.PlayerName1 & "  WINS! "
                    btnPlayer2Wins.Text = player2.PlayerName1 & "  WINS!"
                    btnPlayer1win.Visible = True
                    btnPlayer2Wins.Visible = True
                    btnReg.Visible = False
                    btnSave.Visible = False
                    btnQuit.Text = "Back"
                    screen = AppState.Switch
                Else 'we'll open current wins
#Region "beta games SQL"
                    'With sqlConnection
                    '    .ConnectionString = connectionString
                    '    .Open()
                    'End With

                    'adapter = New SqlDataAdapter("Select wins from Players where playerName In ('" & cbPlayer1.SelectedItem.ToString & "','" & cbPlayer2.SelectedItem.ToString & "')", sqlConnection)
                    'adapter.Fill(ds)

                    ''save new wins if null txtbox wins, else then insert new game results.
                    'Try
                    '    txtWins.Text = ds.Tables(0).Rows(0).Item(0).ToString
                    '    txtWins2.Text = ds.Tables(0).Rows(1).Item(0).ToString
                    'Catch ex As Exception
                    '    sqlConnection.Close()
                    '    lblError.Text = "Name not found"
                    '    lblError.Visible = True
                    'Finally
                    '    sqlConnection.Close()

                    'End Try
#End Region
                    screen = AppState.SelectPlayer
                    Dim currentWins As String() = Me.player1.GetGames(player2.PlayerName1)
                    Try
                        txtWins.Text = currentWins(0)
                        txtWins2.Text = currentWins(1)
                    Catch ex As Exception
                        lblError.Text = currentWins(0)
                    End Try
                    SetError(lblError)

                End If
#End Region
            End If
        Else
            lblError.Text = "Error: Select Both Players"
            SetError(lblError)
            screen = -1
        End If
    End Sub

    Private Sub btnReg_Click(sender As Object, e As EventArgs) Handles btnReg.Click
        txtWins.Visible = False
        txtWins2.Visible = False
        lblError.Visible = False
        Dim retVal As String = String.Empty
        'If players have names, then update cbox and add them to db
        If Not String.IsNullOrEmpty(tbPlayer1.Text) Then
            screen = AppState.Register

            cbPlayer1.BeginUpdate()
            cbPlayer2.BeginUpdate()

            player1 = New PlayerStats
            player1.PlayerName1 = tbPlayer1.Text

            Try
                lblError.Text = player1.InsertPlayer()
            Catch ex As Exception
                lblError.Text = ex.ToString
            End Try
            SetError(lblError)

#Region "Beta add player sql"
            'With sqlConnection
            '    .ConnectionString = connectionString
            '    .Open()
            'End With

            'Try
            '    With dbCommand
            '        .Connection = sqlConnection
            '        .CommandText = command
            '        .ExecuteNonQuery()

            '    End With
            'Catch ex As Exception
            '    sqlConnection.Close()
            '    lblError.Text = "Name not found"
            '    lblError.Visible = True
            'Finally
            '    sqlConnection.Close()
            'End Try
#End Region

            cbPlayer1.EndUpdate()
            cbPlayer2.EndUpdate()

#Region "Controls"

            With cbPlayer1.Items
                .Add(tbPlayer1.Text)
            End With

            With cbPlayer2.Items
                .Add(tbPlayer1.Text)
            End With

            lblError.Text = "New Players Added"
            lblError.Visible = True
            tbPlayer1.ResetText()
            tbPlayer2.ResetText()
            tbPlayer1.Visible = False
            tbPlayer2.Visible = False
            cbPlayer1.Visible = True
            cbPlayer2.Visible = True
            btnSave.Visible = True
            screen = AppState.Start
#End Region
        Else
            If screen = 1 Then
#Region "Controls"
                lblError.Text = "Back"
                lblError.Visible = True
                tbPlayer1.ResetText()
                tbPlayer2.ResetText()
                tbPlayer1.Visible = False
                tbPlayer2.Visible = False
                cbPlayer1.Visible = True
                cbPlayer2.Visible = True
                txtWins.Visible = True
                txtWins2.Visible = True
                btnSave.Visible = True
                cbPlayer1.Refresh()
                cbPlayer2.Refresh()
                screen = AppState.Start
#End Region
            Else
                tbPlayer1.Visible = True
                cbPlayer1.Visible = False
                cbPlayer2.Visible = False
                btnSave.Visible = False
                screen = AppState.Register
            End If

        End If
        Refresh()
    End Sub

    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs)
        Try
            Me.PlayersTableAdapter.FillBy(Me.PlayerNames.Players)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub FillBy1ToolStripButton_Click(sender As Object, e As EventArgs)
        Try
            Me.PlayersTableAdapter.FillBy1(Me.PlayerNames.Players)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub cbPlayer1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbPlayer1.SelectedIndexChanged
        Dim isRivarly As Boolean = False
        tbPlayer1.Visible = False
        tbPlayer2.Visible = False
        lblError.Visible = False
        txtWins.Visible = True
        txtWins2.Visible = True

        If screen <> AppState.Register Then
            player1.PlayerName1 = cbPlayer1.SelectedItem
            lblError.Text = player1.GetPlayers()
            SetError(lblError)
#Region "beta sql"
            'With sqlConnection
            '    .ConnectionString = connectionString
            '    .Open()
            'End With

            ''save new wins if null txtbox wins, else then insert new game results.
            'Try
            '    adapter = New SqlDataAdapter("Select wins from Players where playerName In ('" & cbPlayer1.SelectedItem & "')", sqlConnection)
            '    adapter.Fill(ds)
            '    txtWins.Text = ds.Tables(0).Rows(0).Item(0).ToString
            '    playerStats1.Wins1 = txtWins.Text
            '    If (Not String.IsNullOrEmpty(txtWins.Text) AndAlso Not String.IsNullOrEmpty(txtWins2.Text)) Then
            '        If playerStats1.getRivarly(txtWins2.Text) Then
            '            lblError.Text = "Rivarly Game"
            '            lblError.Text = Visible
            '            lblError.ForeColor = Color.Black
            '        End If
            '    End If


            'Catch ex As Exception
            '    sqlConnection.Close()
            '    lblError.Text = "Name not found"
            '    lblError.Visible = True
            'Finally
            '    sqlConnection.Close()

            'End Try
#End Region
            txtWins.Text = player1.Wins1
            If Not String.IsNullOrEmpty(player2.PlayerName1) Then
                screen = AppState.Switch
            End If
            isRiv = player1.getRivarly(player2.Wins1)
            If isRiv Then
                lblError.Text = "Rivarly"
                SetError(lblError)
            End If
        End If

    End Sub

    Private Sub cbPlayer2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbPlayer2.SelectedIndexChanged
        Dim isRivarly As Boolean = False
        tbPlayer1.Visible = False
        tbPlayer2.Visible = False
        lblError.Visible = False
        txtWins.Visible = True
        txtWins2.Visible = True

        If screen <> AppState.Register Then
            player2.PlayerName1 = cbPlayer2.SelectedItem
            lblError.Text = player2.GetPlayers()
            SetError(lblError)
            txtWins2.Text = player2.Wins1
            If Not String.IsNullOrEmpty(player1.PlayerName1) Then
                screen = AppState.Switch
            End If
            isRiv = player2.getRivarly(player1.Wins1)
            If isRiv Then
                lblError.Text = "Rivarly"
                SetError(lblError)
            End If
        End If
    End Sub

    Private Sub FillByToolStripButton_Click_1(sender As Object, e As EventArgs)
        Try
            Me.PlayersTableAdapter1.FillBy(Me.LocalResultsDataSet1.Players)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnPlayer1win_Click(sender As Object, e As EventArgs) Handles btnPlayer1win.Click
        screen = AppState.Winner
        Dim gameResults As String = String.Empty
#Region "Beta sql"
        'With SqlConnection
        '    .ConnectionString = connectionString
        '    .Open()
        'End With

        'playerStats1.Wins1 += 1
        'adapter = New SqlDataAdapter("exec dbo.[insWins_v1.1] @newPlayer = '" & playerStats1.PlayerName1 & "',@wins = " & playerStats1.Wins1, sqlConnection)
        'adapter.Fill(ds)

        'Try
        '    adapter = New SqlDataAdapter("select wins from Players where playerName in ('" & cbPlayer1.SelectedItem & "')", sqlConnection)
        '    adapter.Fill(ds)
        '    txtWins.Text = ds.Tables(0).Rows(0).Item(0).ToString
        'Catch ex As Exception
        '    SqlConnection.Close()
        '    lblError.Text = "Game not saved"
        '    lblError.Visible = True
        'Finally
        '    btnPlayer1win.Visible = False
        '    btnPlayer2Wins.Visible = False
        '    btnReg.Visible = True
        '    btnSave.Visible = True
        '    sqlConnection.Close()
        'End Try
#End Region
        gameResults = player1.InsertGame("")
        If (gameResults).Contains("Error") Then
            lblError.Text = gameResults
        Else
            txtWins.Text = gameResults
        End If
        btnPlayer1win.Visible = False
        btnPlayer2Wins.Visible = False
        btnReg.Visible = True
        btnSave.Visible = True
    End Sub

    Private Sub btnPlayer2Wins_Click(sender As Object, e As EventArgs) Handles btnPlayer2Wins.Click
        screen = AppState.Winner
        Dim gameResults As String = String.Empty

#Region "beta sql"
        'With sqlConnection
        '    .ConnectionString = connectionString
        '    .Open()
        'End With

        'playerStats2.Wins1 += 1
        'adapter = New SqlDataAdapter("exec dbo.[insWins_v1.1] @newPlayer = '" & playerStats2.PlayerName1 & "',@wins = " & playerStats2.Wins1, sqlConnection)
        'adapter.Fill(ds)

        'Try
        '    adapter = New SqlDataAdapter("select wins from Players where playerName in ('" & cbPlayer2.SelectedItem.ToString & "')", sqlConnection)
        '    adapter.Fill(ds)

        '    txtWins2.Text = ds.Tables(0).Rows(0).Item(0).ToString
        'Catch ex As Exception
        '    sqlConnection.Close()
        '    lblError.Text = "Game not saved"
        '    lblError.Visible = True
        'Finally
        '    btnPlayer1win.Visible = False
        '    btnPlayer2Wins.Visible = False
        '    btnReg.Visible = True
        '    btnSave.Visible = True
        '    sqlConnection.Close()
        'End Try
#End Region

        gameResults = player2.InsertGame("")
        If (gameResults).Contains("Error") Then
            lblError.Text = gameResults
        Else
            txtWins2.Text = gameResults
        End If
        btnPlayer1win.Visible = False
        btnPlayer2Wins.Visible = False
        btnReg.Visible = True
        btnSave.Visible = True
    End Sub

    Protected Sub SetError(ByRef errorText As Label)
        If errorText.Text.Contains("Error") Then
            errorText.ForeColor = Color.Red
            errorText.Visible = True
        ElseIf errorText.Text.Contains("Rivarly") Then
            errorText.ForeColor = Color.GreenYellow
            errorText.Visible = True
        Else
            errorText.Visible = False
        End If
    End Sub

    Private Sub btnHighScore_Click(sender As Object, e As EventArgs) Handles btnHighScore.Click
        Dim myForm As New HighScores
        Me.Hide()
        myForm.Show()
    End Sub

    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        If screen = AppState.Switch Then
            Application.Restart()
            'set menu 1 state
            '

        Else
            Application.Exit()

        End If
    End Sub
End Class
