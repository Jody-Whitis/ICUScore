﻿Imports System.Data.SqlClient
Imports System.IO
Imports PoolDBConnect

Public Class PlayerStats
    Implements PoolDBConnect.IDBConnect

    Private PlayerName As String
    Private Wins As Int32
    Private Loses As Int32
    Private lastOp As String
    Private Results As String
    Private winsAgainst As List(Of String)
    'Private DBConnection As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" &
    '    "C:\Users\jwhitis\source\repos\Pool\Pool\LocalResults.mdf;Integrated Security=True"
    Private DBConnection As String = ("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" & Path.GetDirectoryName(Application.StartupPath) & "\LocalResults.mdf;Integrated Security=True").Replace("\bin", "")
    Private sqlConnection As New SqlConnection
    Private adapter As New SqlDataAdapter

#Region "Properties"
    Public Property PlayerName1 As String
        Get
            Return PlayerName
        End Get
        Set(value As String)
            PlayerName = value
        End Set
    End Property

    Public Property Wins1 As Integer
        Get
            Return Wins
        End Get
        Set(value As Integer)
            Wins = value
        End Set
    End Property

    Public Property Loses1 As Integer
        Get
            Return Loses
        End Get
        Set(value As Integer)
            Loses = value
        End Set
    End Property

    Public Property LastOp1 As String
        Get
            Return lastOp
        End Get
        Set(value As String)
            lastOp = value
        End Set
    End Property

    Public Property Results1 As String
        Get
            Return Results
        End Get
        Set(value As String)
            Results = value
        End Set
    End Property

    Public Property WinsAgainst1 As List(Of String)
        Get
            Return winsAgainst
        End Get
        Set(value As List(Of String))
            winsAgainst = value
        End Set
    End Property
#End Region
    Public Function InsertGame() As String Implements IDBConnect.InsertGame
        Dim ds As New DataSet
        With sqlConnection
            .ConnectionString = DBConnection
            .Open()
        End With
        Wins1 += 1
        adapter = New SqlDataAdapter("exec dbo.[insWins_v1.1] @newPlayer = '" & PlayerName1 & "',@wins = " & Wins1, sqlConnection)
        adapter.Fill(ds)

        Try
            adapter = New SqlDataAdapter("select wins from Players where playerName in ('" & PlayerName1 & "')", sqlConnection)
            adapter.Fill(ds)
            Return ds.Tables(0).Rows(0).Item(0).ToString
        Catch ex As Exception
            sqlConnection.Close()
            Return "Error: Game not saved"

        Finally
            sqlConnection.Close()
        End Try
        Return String.Empty

    End Function

    Public Function InsertPlayer() As String Implements IDBConnect.InsertPlayer
        Dim command As String = "exec insNewPlayer @newPlayer='" & PlayerName1 & "'"
        Dim dbCommand As New SqlCommand

        With sqlConnection
            .ConnectionString = DBConnection
            .Open()
        End With
        Try
            With dbCommand
                .Connection = sqlConnection
                .CommandText = command
                .ExecuteNonQuery()
            End With
            Return String.Empty

        Catch ex As Exception
            sqlConnection.Close()
            Return "Error adding player"

        Finally
            sqlConnection.Close()
        End Try
    End Function

    Public Function GetGames(playerName2 As String) As String() Implements IDBConnect.GetGames
        Dim ds As New DataSet
        Dim retVal = New String(2) {}

        With sqlConnection
            .ConnectionString = DBConnection
            .Open()
        End With

        adapter = New SqlDataAdapter("Select wins from Players where playerName In ('" & PlayerName1 & "','" & playerName2 & "')", sqlConnection)
        adapter.Fill(ds)

        'save new wins if null txtbox wins, else then insert new game results.
        Try
            retVal(0) = ds.Tables(0).Rows(0).Item(0).ToString
            retVal(1) = ds.Tables(0).Rows(1).Item(0).ToString
        Catch ex As Exception
            sqlConnection.Close()
            retVal(0) = "Error"
            Return retVal
        Finally
            sqlConnection.Close()
        End Try
        Return retVal
    End Function

    Public Function getResults() As Object Implements IDBConnect.getResults
        Throw New NotImplementedException()
    End Function
    Public Function GetPlayers() As String Implements IDBConnect.GetPlayers
        Dim ds As New DataSet

        With sqlConnection
            .ConnectionString = DBConnection
            .Open()
        End With

        Try
            'Search by player name
            adapter = New SqlDataAdapter("Select wins from Players where playerName In ('" & PlayerName1 & "')", sqlConnection)
            adapter.Fill(ds)
            Wins1 = ds.Tables(0).Rows(0).Item(0).ToString
        Catch ex As Exception
            sqlConnection.Close()
            Return "Name not found"
        Finally
            sqlConnection.Close()

        End Try
        Return String.Empty
    End Function

    Public Overridable Function getRivarly(ByVal challengerWins) As Boolean
        Dim totalGames As Integer = Wins + challengerWins
        Dim averageWins As Double = Wins / totalGames
        If averageWins >= 0.45 Then
            Return True
        Else
            Return False
        End If
    End Function

End Class
