﻿Imports System.Data.SqlClient
Imports PoolDBConnect

Public Class PlayerStats
    Implements PoolDBConnect.IDBConnect

    Private PlayerName As String
    Private Wins As Int32
    Private Loses As Int32
    Private lastOp As String
    Private Results As String
    Private winsAgainst As List(Of String)
    Private DBConnection As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" &
        "C:\Users\jwhitis\source\repos\Pool\Pool\LocalResults.mdf;Integrated Security=True"
    Private sqlConnection As New SqlConnection
    Private adapter As New SqlDataAdapter

#Region "Properties"
    Public Property PlayerName1 As String
        Get
            Return PlayerName
        End Get
        Set(value As String)
            PlayerName = value
        End Set
    End Property

    Public Property Wins1 As Integer
        Get
            Return Wins
        End Get
        Set(value As Integer)
            Wins = value
        End Set
    End Property

    Public Property Loses1 As Integer
        Get
            Return Loses
        End Get
        Set(value As Integer)
            Loses = value
        End Set
    End Property

    Public Property LastOp1 As String
        Get
            Return lastOp
        End Get
        Set(value As String)
            lastOp = value
        End Set
    End Property

    Public Property Results1 As String
        Get
            Return Results
        End Get
        Set(value As String)
            Results = value
        End Set
    End Property

    Public Property WinsAgainst1 As List(Of String)
        Get
            Return winsAgainst
        End Get
        Set(value As List(Of String))
            winsAgainst = value
        End Set
    End Property
#End Region

    Public Sub GetGames(cb As ComboBox, cb2 As ComboBox, txtwins As TextBox, txtWins2 As TextBox, lblError As Label) Implements IDBConnect.GetGames


    End Sub

    Public Sub GetPlayers(cbPlayer1 As ComboBox, txtwins As TextBox, lblError As Label) Implements IDBConnect.GetPlayers
        Dim ds As New DataSet

        With sqlConnection
            .ConnectionString = DBConnection
            .Open()
        End With

        Try
            'Search by player name
            adapter = New SqlDataAdapter("Select wins from Players where playerName In ('" & cbPlayer1.SelectedItem & "')", sqlConnection)
            adapter.Fill(ds)
            txtwins.Text = ds.Tables(0).Rows(0).Item(0).ToString
            Wins1 = txtwins.Text
        Catch ex As Exception
            sqlConnection.Close()
            lblError.Text = "Name not found"
            lblError.Visible = True
        Finally
            sqlConnection.Close()

        End Try
    End Sub

    Public Sub getResults(tb As TextBox) Implements IDBConnect.getResults
        Throw New NotImplementedException()
    End Sub


    Public Sub InsertGame() Implements IDBConnect.InsertGame
        Throw New NotImplementedException()
    End Sub

    Public Sub InsertPlayer() Implements IDBConnect.InsertPlayer
        Throw New NotImplementedException()
    End Sub

    Public Overridable Function getRivarly(ByVal challengerWins) As Boolean
        Dim totalGames As Integer = Wins + challengerWins
        Dim averageWins As Double = Wins / totalGames
        If averageWins >= 0.45 Then
            Return True
        Else
            Return False
        End If
    End Function
End Class
